#!/bin/bash

DB_TYPES=oracle/postgres/sqlserver/mysql/mariadb

WA_HOME=`pwd`

USER_ARGS=()
CONFIG_FILE_PATH="$WA_HOME/Platform/conf/startUp.properties"

help(){
  echo "Usage: $0 -d=dbType [$DB_TYPES] -y=dbUrl -u=username -p=password -t=tables [; separated, % for wildcard] -e=excludedTables [; separated, % for wildcard] -r=reportType -td=targetDbType"
  echo -e "\ne.g: $0 -d=oracle -y=jdbc:oracle:thin:@//localhost:1521/ORCL -u=root -p=passw0rd -t=schema1.table1;schema2.table_wildcard%;schema3.table3 -e=schema2.my_excluded_table; -td=postgres -y=text"
  echo -e "\ne.g: $0 --dbType=oracle --dbUrl=jdbc:oracle:thin:@//localhost:1521/ORCL --username=root --password=password --tables=schema1.table1;schema2.table_wildcard%;schema3.table3 --excludedTables=schema2.my_excluded_table; --targetDbType=postgres --reportType=text"
  echo ""
  echo "Options"
  echo "Arguments: "
  echo -e "-d\n--dbType"
  echo -e "\tType of the database. One of [$DB_TYPES]"
  echo ""
  echo -e "-y\n--dbUrl"
  echo -e  "\tJDBC URL to connect to the database"
  echo ""
  echo -e "-u\n--username"
  echo -e "\tUser name to connect to the database"
  echo ""
  echo -e "-p\n--password"
  echo -e "\tPassword to connect to the database"
  echo ""
  echo -e "-t\n--tables"
  echo -e "\tSemicolon separated list of tables to be converted from the database. '%%' can be used as a wildcard for matching table names"
  echo ""
  echo -e "-e\n--excludedTables"
  echo -e "\tSemicolon separated list of tables to be excluded from conversion from the database. '%%' can be used as a wildcard for matching table names"
  echo ""
  echo -e "-td\n--targetDbType"
  echo -e "\tType of the target database. One of [$DB_TYPES]. Using this option generates an Integration compatibility section in the report."
  echo ""
  echo -e "-r\n--reportType"
  echo -e "\tReport type to be generated (text/html)"
  echo ""
}

if [ $# -eq 1 ] && [[ "$1" = '-h' || "$1" = '--help' ]]
then
  help
  exit 0
fi

for i in "$@"
 do
 case $i in
    -d=*|--dbType=*)
    DB_TYPE="${i#*=}"
    shift
    ;;
    -y=*|--dbUrl=*)
    DB_URL="${i#*=}"
    shift
    ;;
    -u=*|--username=*)
    DB_USERNAME="${i#*=}"
    shift
    ;;
    -p=*|--password=*)
    DB_PASSWORD="${i#*=}"
    shift
    ;;
    -t=*|--tables=*)
    DB_TABLES="${i#*=}"
    shift
    ;;
    -r=*|--reportType=*)
    REPORT_TYPE="${i#*=}"
    shift
    ;;
    -td=*|--targetDbType=*)
    TARGET_DB_TYPE="${i#*=}"
    shift
    ;;
esac
done

if ! [[ $DB_TYPE ]]
then
  echo "Provide database type"
  exit 1
elif ! [[ $DB_URL ]]
then
  echo "Provide database URL"
    exit 1
elif ! [[ $DB_USERNAME ]]
then
  echo "Provide database username"
  exit 1
elif ! [[ $DB_PASSWORD ]]
then
  echo "Provide database password"
  exit 1
elif ! [[ $DB_TABLES ]]
then
  echo "Provide database tables"
  exit 1
elif ! [[ $REPORT_TYPE ]]
then
  echo "Provide report type"
  exit 1
fi

echo $WA_HOME
JAVA=`command -v java`  || JAVA="java"
${JAVA} $JAVA_SYSTEM_PROPERTIES \
    -cp "$WA_HOME/conf:$WA_HOME/lib/*:$CLASSPATH" \
         -Dlog4j2.configurationFile="log4j.server.properties" \
         -Dstriim.cluster.config.file.path="$CONFIG_FILE_PATH" \
         -Dstriim.node.MigrationResources="$WA_HOME/conf/" \
    com.striim.api.AssessmentReportUtility \
    -dbType $DB_TYPE \
    -dbUrl  $DB_URL \
    -username $DB_USERNAME \
    -password $DB_PASSWORD \
    -tables $DB_TABLES \
    -excludedTables $DB_EXCLUDED_TABLES \
    -reportType $REPORT_TYPE \
    -targetDbType $TARGET_DB_TYPE
